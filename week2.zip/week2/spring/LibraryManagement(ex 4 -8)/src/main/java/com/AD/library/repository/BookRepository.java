package com.AD.library.repository;

import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
}

