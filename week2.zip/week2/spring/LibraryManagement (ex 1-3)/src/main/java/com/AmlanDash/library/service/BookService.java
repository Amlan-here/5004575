package com.AmlanDash.library.service;

import com.AmlanDash.library.repository.BookRepository;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void someMethod() {
        System.out.println("Executing someMethod in BookService");
    }
}


