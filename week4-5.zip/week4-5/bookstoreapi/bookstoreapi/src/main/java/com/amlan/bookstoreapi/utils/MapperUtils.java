package com.amlan.bookstoreapi.utils;

import com.amlan.bookstoreapi.dto.BookDTO;
import com.amlan.bookstoreapi.entity.Book;

public class MapperUtils {

    public static BookDTO mapToDTO(Book book) {
        return new BookDTO(book.getId(), book.getTitle(), book.getAuthor(), book.getPrice(), book.getIsbn());
    }

    public static Book mapToEntity(BookDTO bookDTO) {
        return new Book(bookDTO.getId(), bookDTO.getTitle(), bookDTO.getAuthor(), bookDTO.getPrice(), bookDTO.getIsbn());
    }
}

