package com.amlan.bookstoreapi.repository;

import com.amlan.bookstoreapi.entity.Customer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerRepository extends JpaRepository<Customer, Long> {
}

