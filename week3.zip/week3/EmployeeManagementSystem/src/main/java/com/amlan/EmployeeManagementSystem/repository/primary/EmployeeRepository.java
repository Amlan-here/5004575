package com.amlan.EmployeeManagementSystem.repository.primary;

import com.amlan.EmployeeManagementSystem.model.Employee;
import com.amlan.EmployeeManagementSystem.projection.EmployeeProjection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    List<Employee> findByName(String name);

    // Custom query using @Query annotation
    @Query("SELECT e FROM Employee e WHERE e.email = :email")
    Employee findByEmail(@Param("email") String email);

    // Named query method
    @Query(name = "Employee.findByDepartment")
    List<Employee> findByDepartmentName(@Param("departmentName") String departmentName);

    // Projection method
    List<EmployeeProjection> findAllProjectedBy();
}
