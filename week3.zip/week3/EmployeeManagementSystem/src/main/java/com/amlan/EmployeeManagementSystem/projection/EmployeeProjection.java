package com.amlan.EmployeeManagementSystem.projection;

public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
}

