package week1.exercise3;

public class order {
    private int orderID;
    private String customerName;
    private double totalPrice;
    public order(int orderId, String customerName, double totalPrice)
    {
        this.orderID = orderId;
        this.customerName = customerName;
        this.totalPrice = totalPrice;
    }
    public int getOrderId()
    {
        return orderID;
    }
    public String getCustomerName()
    {
        return customerName;
    }
    public double getTotalPrice()
    {
        return totalPrice;
    }
    public String toString()
    {
        return "Order{" +
                "orderId=" + orderID +
                ", customerName='" + customerName +
                ", totalPrice=" + totalPrice +
                '}';
    }
}



