package week1.exercise3;

import java.util.Arrays;

public class sorting {

    public static void bubbleSort(order[] orders) {
        int n = orders.length;
        for (int i = 0; i < n - 1; i++)
        {
            for (int j = 0; j < n - i - 1; j++)
            {
                if (orders[j].getTotalPrice() > orders[j + 1].getTotalPrice())
                {

                    order temp = orders[j];
                    orders[j] = orders[j + 1];
                    orders[j + 1] = temp;
                }
            }
        }
    }
    public static void quickSort(order[] orders, int low, int high) {
        if (low < high)
        {
            int pi = partition(orders, low, high);
            quickSort(orders, low, pi - 1);
            quickSort(orders, pi + 1, high);
        }
    }

    private static int partition(order[] orders, int low, int high) {
        double pivot = orders[high].getTotalPrice();
        int i = low - 1;

        for (int j = low; j < high; j++)
        {
            if (orders[j].getTotalPrice() <= pivot)
            {
                i++;
                order temp = orders[i];
                orders[i] = orders[j];
                orders[j] = temp;
            }
        }
        order temp = orders[i + 1];
        orders[i + 1] = orders[high];
        orders[high] = temp;

        return i + 1;
    }
    public static void main(String[] args) {
        order[] orders = {
                new order(1, "Amlan", 786),
                new order(2, "Gayatri", 987),
                new order(3, "Abhigyan", 877)
        };

        order[] bubbleSortedOrders = Arrays.copyOf(orders, orders.length);
        bubbleSort(bubbleSortedOrders);
        System.out.println(" Bubble Sort:");                        //BUBBLE SORT
        for (order order : bubbleSortedOrders) {
            System.out.println(order);
        }
        order[] quickSortedOrders = Arrays.copyOf(orders, orders.length);
        quickSort(quickSortedOrders, 0, quickSortedOrders.length - 1);       // QUICK SORT
        System.out.println("Quick Sort:");
        for (order order : quickSortedOrders) {
            System.out.println(order);
        }
    }
}
