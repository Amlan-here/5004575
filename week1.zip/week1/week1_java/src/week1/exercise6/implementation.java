package week1.exercise6;

public class implementation {
    public static void main(String[] args) {
        Book[] books = {
                new Book(1, "physics", "GRV"),
                new Book(2, "math", "R.D sharma"),
                new Book(3, "DSA", "Narasimha Karumanchi")
        };
        Library library = new Library(books);

        String titleToSearch = "physics";
        Book bookFoundLinear = library.linearSearch(titleToSearch);
        if (bookFoundLinear != null) {
            System.out.println(bookFoundLinear.title);
        } else {
            System.out.println("not found");
        }
        titleToSearch = "DSA";
        Book bookFoundBinary = library.binarySearch(titleToSearch);
        if (bookFoundBinary != null) {
            System.out.println(bookFoundBinary.title);
        } else {
            System.out.println("not found ");
        }
    }
}

