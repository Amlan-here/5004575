package week1.exercise5;

public class implementation {
        public static void main(String[] args) {
            TaskLinkedList taskList = new TaskLinkedList();

            Task task1 = new Task(1, "Complete Project Report", "Pending");
            Task task2 = new Task(2, "Schedule Meeting", "Pending");
            Task task3 = new Task(3, "Review Code", "In Progress");


            taskList.addTask(task1);
            taskList.addTask(task2);
            taskList.addTask(task3);


            taskList.traverse();


            Task foundTask = taskList.searchTask(2);
            if (foundTask != null) {
                System.out.println("Found task: " + foundTask.taskName);
            } else {
                System.out.println("Task not found");
            }


            taskList.deleteTask(2);


            System.out.println("Tasks after deletion:");
            taskList.traverse();
        }
    }


