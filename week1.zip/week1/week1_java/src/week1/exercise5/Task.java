package week1.exercise5;

public class Task {
        int taskId;
        String taskName;
        String status;
        public Task(int taskId, String taskName, String status) {
            this.taskId = taskId;
            this.taskName = taskName;
            this.status = status;
        }
    }
    class Node {
        Task data;
        Node next;
        public Node(Task data) {
            this.data = data;
            this.next = null;
        }
    }
    class TaskLinkedList {
        Node head;
        public TaskLinkedList() {
            head = null;
        }
        public void addTask(Task task) {
            Node newNode = new Node(task);      //ADD
            newNode.next = head;
            head = newNode;
        }
        public Task searchTask(int taskId) {
            Node current = head;
            while (current != null) {                  // SEARCH
                if (current.data.taskId == taskId) {
                    return current.data;
                }
                current = current.next;
            }
            return null;
        }
        public void traverse() {                        // TRAVERSE THE LL
            Node current = head;
            while (current != null) {
                System.out.println("Task ID: " + current.data.taskId + ", Task Name: " + current.data.taskName + ", Status: " + current.data.status);
                current = current.next;
            }
        }
        public void deleteTask(int taskId) {       // DELETE
            if (head == null)
            {
                return;
            }
            if (head.data.taskId == taskId)
            {
                head = head.next;
                return;
            }

            Node current = head;
            while (current.next != null)
            {
                if (current.next.data.taskId == taskId)
                {
                    current.next = current.next.next;
                    return;
                }
                current = current.next;
            }
        }
    }


