package week1.exercise2;

import java.util.Arrays;

public class search {

    public static Product linearSearch(Product[] products, String targetName){
        for (Product product : products){
            if (product.getProductName().equals(targetName)){
                return product;
            }
        }
        return null;
    }

    public static Product binarysearch(Product[]products, String targetName){
        int left = 0;
        int right = products.length - 1;

        while (left <= right){
            int mid = left + (right - left) / 2;
            int comparison = products[mid].getProductName().compareTo(targetName);

        if(comparison == 0)
            {
                return products[mid];
            }
        else if(comparison < 0)
            {
                left = mid + 1;
            }
        else
            {
                right = mid-1;
            }
        }
        return null;
    }

    public static void main(String[] args) {
        Product[] products = {
                new Product(1, "bottle", "everday-uses"),
                new Product(2, "television", "electronics"),
                new Product(3, "cycle", "vehicle")
        };
        System.out.println("linear search:");
        Product resultLinear = linearSearch(products,"bottle");
        System.out.println(resultLinear);

        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareTo(p2.getProductName()));
        System.out.println("Binary Search Result:");
        Product resultBinary = binarysearch(products, "bottle");
        System.out.println(resultBinary);

        }
    }

