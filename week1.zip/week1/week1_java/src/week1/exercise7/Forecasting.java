package week1.exercise7;

public class Forecasting {

        private double growthRate;

        public Forecasting(double growthRate) {
            this.growthRate = growthRate;
        }
        public double predictValue(double presentValue, int periods) {
            if (periods == 0)
            {
                return presentValue;
            } else
            {
                return predictValue(presentValue * (1 + growthRate), periods - 1);
            }
        }
        public double predictValueIterative(double presentValue, int periods) {
            for (int i = 0; i < periods; i++) {
                presentValue *= (1 + growthRate);
            }
            return presentValue;
        }
        public static void main(String[] args) {
            Forecasting forecast = new Forecasting(0.05); // 5% growth rate
            double initialInvestment = 1000.0;
            int years = 5;

            // Recursive prediction
            double futureValueRecursive = forecast.predictValue(initialInvestment, years);
            System.out.println("Future value (recursive): $" + futureValueRecursive);

            // Iterative prediction
            double futureValueIterative = forecast.predictValueIterative(initialInvestment, years);
            System.out.println("Future value (iterative): $" + futureValueIterative);
        }
    }



