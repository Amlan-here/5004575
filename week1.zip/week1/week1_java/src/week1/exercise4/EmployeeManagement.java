package week1.exercise4;
public class EmployeeManagement {

    private Employee[] employees;
    private int size;
    public EmployeeManagement(int capacity) {
        employees = new Employee[capacity];
        size = 0;
    }
    public void addEmployee(Employee employee) {
        if (size >= employees.length) {
            System.out.println(" Cannot add more employees.");
            return;
        }
        employees[size++] = employee;
    }
    public Employee searchEmployeeById(int employeeId) {
        for (int i = 0; i < size; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }
    public void printAllEmployees() {
        if (size == 0)
        {
            System.out.println("No employees to display.");
            return;
        }
        for (int i = 0; i < size; i++)
        {
            System.out.println(employees[i]);
        }
    }

    public void deleteEmployeeById(int employeeId) {
        int index = -1;
        for (int i = 0; i < size; i++)
        {
            if (employees[i].getEmployeeId() == employeeId) {
                index = i;
                break;
            }
        }

        if (index == -1)
        {
            System.out.println("Employee not found.");
            return;
        }

        // Shift elements to the left
        for (int i = index; i < size - 1; i++)
        {
            employees[i] = employees[i + 1];
        }
        employees[size - 1] = null; // Clear last element
        size--;
    }


    public static void main(String[] args) {
        EmployeeManagement empManager = new EmployeeManagement(5);

        empManager.addEmployee(new Employee(1, "Amlan", "manager", 123456));
        empManager.addEmployee(new Employee(2, "Aman", "asstmanager", 75548));
        empManager.addEmployee(new Employee(3, "jaydeep", "fieldwork", 55548));
        empManager.addEmployee(new Employee(4, "subham", "fieldwork", 55543));
        empManager.addEmployee(new Employee(5, "bismay", "fieldwork", 5365485));
        empManager.addEmployee(new Employee(6, "kk", "fieldwork", 5455448));
        empManager.addEmployee(new Employee(7, "roshan", "fieldwork", 455548));

        System.out.println("All Employees:");
        empManager.printAllEmployees();

        System.out.println("Searching for employee with ID 2:");
        Employee emp = empManager.searchEmployeeById(5);
        if (emp != null)
        {
            System.out.println(emp);
        } else
        {
            System.out.println("Employee not found.");
        }
        System.out.println("Deleting employee with ID 7:");
        empManager.deleteEmployeeById(7);
        empManager.printAllEmployees();
    }
}

