package week1.exercise1;

import java.util.HashMap;
import java.util.Map;

public class InventoryManagementSystem {
    // Inner Product class
    static class Product {
        int productId;
        String productName;
        int quantity;
        double price;

        public Product(int productId, String productName, int quantity, double price) {
            this.productId = productId;
            this.productName = productName;
            this.quantity = quantity;
            this.price = price;
        }

        public String toString() {
            return "Product{" +
                    "productId=" + productId +
                    ", productName='" + productName + '\'' +
                    ", quantity=" + quantity +
                    ", price=" + price +
                    '}';
        }
    }
    private Map<Integer, Product> products = new HashMap<>();


    public void addProduct(Product product) {
        products.put(product.productId, product);
    }
    public void updateProduct(int productId, int newQuantity) {
        Product product = products.get(productId);
        if (product != null) {
            product.quantity = newQuantity;
        }
    }
    public void deleteProduct(int productId) {
        products.remove(productId);
    }
    public Product getProduct(int productId) {
        return products.get(productId);
    }


    public static void main(String[] args) {
        InventoryManagementSystem ims = new InventoryManagementSystem();

        ims.addProduct(new Product(1, "Laptop", 10, 999.99));
        System.out.println("Added product: " + ims.getProduct(1));

        ims.updateProduct(1, 15);
        System.out.println("Updated product quantity: " + ims.getProduct(1).quantity);

        ims.deleteProduct(1);
        System.out.println("Deleted product: " + ims.getProduct(1));
    }
}
